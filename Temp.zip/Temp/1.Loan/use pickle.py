import pandas as pd
import pickle

with open(r'C:\Users\Acer\Desktop\LR.pkl', 'rb') as file:  
    Pickled_LR_Model = pickle.load(file)

print(Pickled_LR_Model)

gender=input("What is your gender:")
married=input("Married:")
dependents=input("dependents value:")
Education=input("enter your education:")
SelfEmployed=input("Self Employed:")
ApplicantIncome=int(input("enter applicant income:"))
coApplicantIncome=int(input("enter co applicant income:"))
LoanAmount=int(input("enter loan amount:"))
LoanAmountTerm=int(input("enter loan amount term:"))
CreditHistory=int(input("enter credit history:"))
PropertyArea=input("enter property area:")

data = [[gender,married,dependents,Education,SelfEmployed,ApplicantIncome,coApplicantIncome,LoanAmount,LoanAmountTerm,CreditHistory,PropertyArea]]

newdf = pd.DataFrame(data, columns = ['Gender','Married','Dependents','Education','Self_Employed','ApplicantIncome','CoapplicantIncome','LoanAmount','Loan_Amount_Term','Credit_History','Property_Area'])

newdf = pd.get_dummies(newdf)

XtrainCols=['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
       'Loan_Amount_Term', 'Credit_History', 'Gender_Female', 'Gender_Male',
       'Married_No', 'Married_Yes', 'Dependents_0', 'Dependents_1',
       'Dependents_2', 'Dependents_3+', 'Education_Graduate',
       'Education_Not Graduate', 'Self_Employed_No', 'Self_Employed_Yes',
       'Property_Area_Rural', 'Property_Area_Semiurban',
       'Property_Area_Urban']

missing_cols = set( XtrainCols ) - set( newdf.columns )
for c in missing_cols:
    newdf[c] = 0

newdf = newdf[XtrainCols]
yp=Pickled_LR_Model.predict(newdf)

print(yp[0])

input()
input()