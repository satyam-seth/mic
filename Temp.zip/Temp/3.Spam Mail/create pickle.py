import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import accuracy_score
import re
from nltk.corpus import stopwords
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score
import pickle

df = pd.read_csv('datasets_483_982_spam.csv',encoding='latin-1')
new_data = df[['v1','v2']]

new_data['v1'] = new_data['v1'].apply(lambda x: 1 if x == 'ham' else 0)

stop_words = set(stopwords.words('english'))
def nlp_preprocessing(total_text, index, column):
    if type(total_text) is not int:
        string = ""
        total_text = re.sub('[^a-zA-Z0-9\n]', ' ', total_text)
        total_text = re.sub('\s+',' ', total_text)
        total_text = total_text.lower()
        for word in total_text.split():
            if not word in stop_words:
                string += word + " "
        new_data[column][index] = string

for index, row in new_data.iterrows():
    if type(row['v2']) is str:
        nlp_preprocessing(row['v2'], index, 'v2')
    else:
        print("there is no text description for id:",index)

y = new_data['v1']
X = new_data['v2']

count_vect = CountVectorizer()
count_vect.fit(X)
X1 = count_vect.transform(X)

X_train, X_test, y_train, y_test = train_test_split(X1, y, test_size=0.33, random_state=42)

clf = SGDClassifier(alpha=0.0001, penalty='l2', loss='log', random_state=42)
clf.fit(X_train, y_train)
predict_y = clf.predict(X_test)
acc = accuracy_score(y_test, predict_y)

print(f"For alpha value 0.0001 i got accuracy is {acc*100}")

Pkl_Filename = "count_vect.pkl"  

with open(Pkl_Filename, 'wb') as file:  
    pickle.dump(count_vect, file)

Pkl_Filename = "Spam_Model.pkl"  

with open(Pkl_Filename, 'wb') as file:  
    pickle.dump(clf, file)